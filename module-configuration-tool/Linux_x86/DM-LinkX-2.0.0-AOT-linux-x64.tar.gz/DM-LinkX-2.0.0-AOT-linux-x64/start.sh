#!/bin/sh
# 从任意工作目录启动，不依赖全局安装的 .NET。
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$HERE/DM-LinkX" "$@"
