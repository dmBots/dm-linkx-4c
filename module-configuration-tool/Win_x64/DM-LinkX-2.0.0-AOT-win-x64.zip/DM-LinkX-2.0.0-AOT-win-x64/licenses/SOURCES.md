# USB 共享库与对应源码

本软件通过可替换的 USB 共享库使用 LibUsbDotNet（LGPL-3.0-or-later）。
Copyright © 2006–2010 Travis Robinson; © 2011–2023 LibUsbDotNet contributors; © 2026 BeanPaste233.

桥接版本：0.1.1.0；ABI：0x00010001。
对应源码包：DM-LinkX-2.0.0-USB-Source.zip，SHA256：0e9cc12034de8abb8e21a38140ca759969fe8be05a14d0de4c783f7a96a07fbe。
请与程序在同一位置提供下载，内含本次实际构建的 USB 库/桥接源码与构建脚本。
修改后退出程序并替换兼容 DLL/SO 即可；无需重新链接主程序。
配置器和设备 SDK 的协议源码、应用 IL 不在材料内。底层 libusb 保持动态链接。
GPL/LGPL 全文及替换/调试授权见本目录，替换步骤见源码包 README.md。
