/**
 * @file dmecat_types.h
 * @brief dmecat SDK 公共类型、协议常量与错误码（主站侧）
 *
 * 线格式出处：`app_linkx/docs/ECAT_PDO_PROTOCOL_V3.md`（协议 v3；主站适配说明见
 * `app_linkx/docs/ECAT_PDO_V3_MASTER_ADAPT.md`）。
 * 所有多字节整数一律**小端**；结构体只用于内存表达，**不代表线上布局**（线上按偏移手工拼装）。
 */
#ifndef DMECAT_TYPES_H
#define DMECAT_TYPES_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── v8 头长度与 PDO 总长 ─────────────────────────────────────────── */
/* v8：单 RPDO/TPDO，无记录级 ACK；窗口 ACK 固定在 RPDO 0x10/0x14：
 *   RPDO = 56B 头 + 1272B 记录区 = 1328B（总长不变，避免 SSC 重新生成）
 *   TPDO = 24B 头 + 1280B 记录区 = 1304B
 * Record control 的 bits12..27 保留，不再承载记录级序号。 */
/** @brief RPDO 头长度（字节，v8） */
#define DMECAT_RPDO_HEADER_BYTES 56u
/** @brief TPDO 头长度（字节，v8） */
#define DMECAT_TPDO_HEADER_BYTES 24u
/** @brief 单条 CAN Record 的固定头长度（字节） */
#define DMECAT_RECORD_HEADER_BYTES 16u
/** @brief TPDO Record 区容量（字节，SSC 档） */
#define DMECAT_RECORD_AREA_BYTES 1280u
/** @brief RPDO Record 区容量（字节，为窗口 ACK 让出 8B） */
#define DMECAT_RPDO_RECORD_AREA_BYTES 1272u
/** @brief RPDO 总长度 = 56 + 1272 = 1328（SSC 尺寸不变） */
#define DMECAT_RPDO_BYTES (DMECAT_RPDO_HEADER_BYTES + DMECAT_RPDO_RECORD_AREA_BYTES)
/** @brief TPDO 总长度 = 24 + 1280 = 1304 */
#define DMECAT_TPDO_BYTES (((DMECAT_TPDO_HEADER_BYTES + DMECAT_RECORD_AREA_BYTES) + 7u) & ~7u)
/** @brief CAN 通道数 */
#define DMECAT_CHANNELS 4u
/** @brief 单帧最大 payload（CAN FD 64B） */
#define DMECAT_MAX_PAYLOAD 64u

/* ── 通道状态位（TPDO `ch_state[]`，v3 §2.2） ──────────────────────── */
#define DMECAT_CH_STATE_WARNING 0x01u       /**< bit0 warning */
#define DMECAT_CH_STATE_ERROR_PASSIVE 0x02u /**< bit1 error-passive */
#define DMECAT_CH_STATE_BUS_OFF 0x04u       /**< bit2 bus-off */
#define DMECAT_CH_STATE_CFG_INVALID 0x40u   /**< bit6 位率配置无效（bit3/4/5 v3 保留不用） */

/* ── CAN Record control 位（v3 §2.3） ──────────────────────────────── */
#define DMECAT_REC_CTRL_DLC_MASK 0x0000000Fu  /**< bits0..3  DLC 码 */
#define DMECAT_REC_CTRL_BRS 0x00000010u       /**< bit4      BRS（仅 FD） */
#define DMECAT_REC_CTRL_FDF 0x00000020u       /**< bit5      FDF（1 = CAN FD） */
#define DMECAT_REC_CTRL_IDE 0x00000040u       /**< bit6      IDE（1 = 扩展 ID） */
#define DMECAT_REC_CTRL_RTR 0x00000080u       /**< bit7      RTR（远程帧，无数据） */
#define DMECAT_REC_CTRL_ESI 0x00000100u       /**< bit8      ESI（RPDO 侧填 0） */
#define DMECAT_REC_CTRL_TS_VALID 0x00000200u  /**< bit9      定时记录（timestamp_us 有效） */
/** @brief bits10..11 **记录自带的通道号**（v3 新增：记录顺序不再按通道分段） */
#define DMECAT_REC_CTRL_CH_SHIFT 10u
#define DMECAT_REC_CTRL_CH_MASK 0x00000C00u
/** @brief bits12..27 保留；v8 不再使用记录级序号 */
#define DMECAT_REC_CTRL_SEQ_SHIFT 12u
#define DMECAT_REC_CTRL_SEQ_MASK 0x0FFFF000u

/**
 * @brief 返回码 / 错误码
 *
 * @note 0..9 与线上 `last_error` 及固件 `ecat_wire_err_t` 同值（报告 §10），
 *       便于主站直接回显从站错误；≥100 是 SDK 本地错误，不上线。
 */
typedef int32_t dmecat_status_t;
enum
{
    DMECAT_OK = 0,                    /**< 0 无错误 */
    DMECAT_ERR_VERSION = 1,           /**< 1 版本/头长不符 */
    DMECAT_ERR_LENGTH = 2,            /**< 2 长度或计数不一致、越界 */
    DMECAT_ERR_RECORD_FORMAT = 3,     /**< 3 Record 字段非法（DLC/ID/RTR+FDF 等） */
    DMECAT_ERR_NO_CREDIT = 4,         /**< 4 额度不足 */
    DMECAT_ERR_BATCH_GAP = 5,         /**< 5 批次号缺口 */
    DMECAT_ERR_SESSION = 6,           /**< 6 会话（epoch）不匹配 */
    DMECAT_ERR_DC_UNLOCKED = 7,       /**< 7 DC 未锁（定时记录被拒） */
    DMECAT_ERR_LATE_BATCH = 8,        /**< 8 目标周期已过 / 批次回退 */
    DMECAT_ERR_TIMESTAMP_ORDER = 9,   /**< 9 同通道定时记录时间倒退 */
    DMECAT_ERR_AREA_FULL = 100,       /**< 100 Record 区放不下（本地） */
    DMECAT_ERR_ARG = 101,             /**< 101 入参非法（本地） */
    DMECAT_ERR_NOT_SUPPORTED = 102,   /**< 102 当前阶段未实现（本地） */
    DMECAT_ERR_IO = 103,              /**< 103 邮箱/状态操作失败（本地；详见 `backend.last_error()`） */
    DMECAT_ERR_QUEUE_FULL = 104,      /**< SDK 待发队列满，使用成功前缀重试 */
    DMECAT_ERR_STATE = 105,           /**< 当前生命周期状态不允许此操作 */
    DMECAT_ERR_DEPENDENCY = 106,      /**< SOEM 运行库不是支持的 2.0.0 */
    DMECAT_ERR_NO_MEMORY = 107,       /**< 内存分配失败 */
    DMECAT_ERR_BUFFER = 108,          /**< 调用方缓冲不足 */
    DMECAT_ERR_CALLBACK = 109,        /**< 回调上下文禁止生命周期操作 */
};

/**
 * @brief 一帧 CAN / CAN FD（主站视角）
 *
 * @note `dlc` 是**协议 DLC 码**（0..15），`dlen` 是其对应的有效字节数：
 *       FD 的 0..8 → 0..8，9..15 → 12/16/20/24/32/48/64；经典 CAN 只允许 0..8。
 *       `rtr = 1` 时 `dlen` 必须为 0（RTR 不携带数据，且不能与 `fdf` 同时置位）。
 */
#pragma pack(push, 8)
typedef struct
{
    uint64_t timestamp_us; /**< RPDO：定时记录"最早允许提交"的 DC µs；TPDO：设备捕获时间（`ts_valid=1` 才有效） */
    uint32_t can_id;       /**< 标准帧 ≤ 0x7FF；扩展帧 ≤ 0x1FFFFFFF（按 `ide` 判定） */
    uint8_t channel;       /**< 通道号 0..3 */
    uint8_t dlc;           /**< DLC 码 0..15 */
    uint8_t dlen;          /**< payload 有效字节数 */
    uint8_t ide;           /**< 1 = 扩展 ID */
    uint8_t rtr;           /**< 1 = 远程帧 */
    uint8_t fdf;           /**< 1 = CAN FD 帧 */
    uint8_t brs;           /**< 1 = FD 数据段变速（仅 `fdf=1` 有意义） */
    uint8_t esi;           /**< TPDO 回传的控制器 ESI；主站发送时固定 0 */
    uint8_t ts_valid;      /**< 1 = `timestamp_us` 有效 */
    uint8_t reserved0;     /**< ABI v1 保留填充，发送时填 0 */
    uint16_t seq;          /**< 保留字段；v8 不再使用记录级序号 */
    uint8_t payload[DMECAT_MAX_PAYLOAD]; /**< 数据（`dlen` 之后的字节忽略） */
} dmecat_frame_t;
#pragma pack(pop)

#if defined(__cplusplus)
static_assert(sizeof(dmecat_frame_t) == 88u, "dmecat ABI v1 frame size");
static_assert(offsetof(dmecat_frame_t, payload) == 24u, "dmecat ABI v1 payload offset");
#elif defined(__STDC_VERSION__) && (__STDC_VERSION__ >= 201112L)
_Static_assert(sizeof(dmecat_frame_t) == 88u, "dmecat ABI v1 frame size");
_Static_assert(offsetof(dmecat_frame_t, payload) == 24u, "dmecat ABI v1 payload offset");
#endif

#ifdef __cplusplus
}
#endif

#endif /* DMECAT_TYPES_H */
