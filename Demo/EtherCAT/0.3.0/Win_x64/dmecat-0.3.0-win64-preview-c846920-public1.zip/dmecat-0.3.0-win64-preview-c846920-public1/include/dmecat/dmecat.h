/**
 * @file dmecat.h
 * @brief dmecat ABI v1：Windows x64 / SOEM 2.0.0 动态运行库。
 * @note open→配置通道→注册回调→start→submit→stop→close。
 *       同一网卡只能由一个主站使用；close 前调用方必须停止其他线程对句柄的访问。
 *       帧结构大小固定为88B，不是PDO线格式；数组步长在 ABI v1 内不变。
 */
#ifndef DMECAT_API_H
#define DMECAT_API_H
#include "dmecat_export.h"
#include "dmecat_types.h"
#include "dmecat_version.h"
#ifdef __cplusplus
extern "C" {
#endif

/** @brief 不透明设备句柄；仅由 open/close 管理其内存。 */
typedef struct dmecat_device dmecat_device_t;
/** @brief 停止态，可进行 PREOP 配置。 */
#define DMECAT_STATE_STOPPED 0u
/** @brief 数据面已启动。 */
#define DMECAT_STATE_RUNNING 1u
/** @brief 正在停止，禁止启动或重新配置。 */
#define DMECAT_STATE_STOPPING 2u
/** @brief 周期线程异常退出；必须先stop回收资源，再配置或重启。 */
#define DMECAT_STATE_FAULTED 3u

#pragma pack(push, 8)
/** @brief 后端选择；DEFAULT使用当前平台发行包的后端。 */
#define DMECAT_BACKEND_DEFAULT 0u
/** @brief Windows发行包的SOEM 2.0.0动态后端。 */
#define DMECAT_BACKEND_SOEM 1u
/** @brief Linux发行包的IgH 1.5.4用户态动态后端。 */
#define DMECAT_BACKEND_IGH 2u
/** @brief SyncManager同步，默认模式。 */
#define DMECAT_SYNC_SM 0u
/** @brief 分布式时钟SYNC0同步；不表示主机具备硬实时保证。 */
#define DMECAT_SYNC_DC 1u

/** @brief 扩展打开参数；独立结构保留旧open配置的576B布局。 */
typedef struct
{
    uint32_t struct_size; /**< 必须由init_open_options初始化 */
    uint32_t backend;     /**< DEFAULT、SOEM或IGH；不支持的后端明确拒绝 */
    uint32_t sync_mode;   /**< SM或DC，默认SM */
    int32_t dc_shift_ns;  /**< SYNC0相移；绝对值小于周期；SM必须为0 */
    uint32_t reserved[4]; /**< 保留，必须为0 */
} dmecat_open_options_t;

/** @brief 缓存的同步配置回读；active不是DC锁定或相位误差测量。 */
typedef struct
{
    uint32_t struct_size;      /**< 调用方结构大小 */
    uint32_t backend;          /**< 当前实际后端 */
    uint32_t sync_mode;        /**< 请求的同步模式 */
    uint32_t active;           /**< 本轮已完成配置验证且周期线程运行 */
    uint32_t output_sync_type; /**< start成功时0x1C32:01回读；停止后保留 */
    uint32_t input_sync_type;  /**< start成功时0x1C33:01回读；停止后保留 */
    uint32_t period_ns;        /**< 请求的PDO/SYNC0周期 */
    int32_t dc_shift_ns;       /**< 请求的SYNC0相移 */
} dmecat_sync_status_t;

/** @brief 网卡枚举项；固定UTF-8缓冲，名称直接交给 open。 */
typedef struct
{
    char name[512];        /**< NPF 设备路径 */
    char description[512];/**< 网卡说明 */
} dmecat_adapter_t;

/** @brief 打开参数；必须使用 init_open_config 初始化，reserved 保持0。 */
typedef struct
{
    uint32_t struct_size;       /**< 调用方结构大小 */
    uint32_t abi_version;       /**< 必须为 DMECAT_ABI_VERSION */
    char adapter[512];         /**< 网卡完整名称；不接受模糊匹配 */
    uint32_t slave;             /**< 首版只支持位置1、单从站 */
    uint32_t period_us;         /**< 周期，默认1000us */
    uint32_t frames_per_ch;     /**< 单拍单通道配额，1..255，受预算/credit约束 */
    uint32_t tx_queue_per_ch;   /**< 16..65536，向上取整至2的幂 */
    uint32_t rx_queue_frames;   /**< 80..65536；整窗入队，不足时不推进ACK */
    uint32_t rx_timeout_us;     /**< 1..period_us-1 */
    uint32_t reserved[8];       /**< 保留，必须为0 */
} dmecat_open_config_t;

/** @brief 通道位率参数；80MHz CAN时钟，结构布局固定32B。 */
typedef struct
{
    uint32_t struct_size;       /**< 调用方结构大小 */
    uint32_t enable_canfd;      /**< 0=经典CAN，1=CANFD；BRS由帧字段指定 */
    uint16_t nominal_brp;       /**< 仲裁段分频 */
    uint16_t nominal_seg1;      /**< 仲裁段TSEG1 */
    uint16_t nominal_seg2;      /**< 仲裁段TSEG2 */
    uint16_t nominal_sjw;       /**< 仲裁段SJW */
    uint16_t data_brp;          /**< 数据段分频 */
    uint16_t data_seg1;         /**< 数据段TSEG1 */
    uint16_t data_seg2;         /**< 数据段TSEG2 */
    uint16_t data_sjw;          /**< 数据段SJW */
    uint16_t enable_tdc;        /**< 0=关闭，1=开启TDC */
    uint16_t tdc_offset;        /**< 0=SDK自动计算 */
    uint16_t tdc_filter;        /**< TDC滤波值 */
    uint16_t reserved;          /**< 必须为0 */
} dmecat_baud_config_t;

/** @brief 扫描时获取的设备信息；channel_count与当前实际PDO尺寸一并校验。 */
typedef struct
{
    uint32_t struct_size;       /**< 调用方结构大小 */
    uint32_t slave;             /**< 从站位置 */
    uint32_t channel_count;     /**< 通道数，目前为4 */
    uint32_t vendor_id;         /**< SII VendorID */
    uint32_t product_code;      /**< SII ProductCode */
    uint32_t revision;          /**< SII Revision（不是固件构建版本） */
    uint32_t has_dc;            /**< ESC能力，仅供信息展示 */
    uint32_t pdo_protocol;      /**< 当前支持的PDO协议版本8 */
    uint32_t rpdo_bytes;        /**< SM2字节数 */
    uint32_t tpdo_bytes;        /**< SM3字节数 */
} dmecat_device_info_t;

/** @brief 当前运行周期的统计快照；tx_submitted不代表CAN上线完成。 */
typedef struct
{
    uint32_t struct_size;       /**< 调用方结构大小 */
    uint32_t state;             /**< DMECAT_STATE_* */
    uint64_t tx_enqueued;       /**< submit成功进入SDK队列 */
    uint64_t tx_submitted;      /**< WKC达标后从本地队列出队 */
    uint64_t tx_queue_full;     /**< 本地队列拒绝次数 */
    uint64_t tx_retry_batches;  /**< WKC不足的批次次数 */
    uint64_t tx_cancelled;      /**< stop取消的本地待发帧 */
    uint64_t rx_queued;         /**< 已进入SDK交付队列 */
    uint64_t rx_delivered;      /**< 回调成功返回的帧数 */
    uint64_t rx_backpressure;   /**< 有界交付队列无空间的次数 */
    uint64_t rx_unhandled;      /**< 未注册回调而消费的帧数 */
    uint64_t callback_errors;   /**< 用户C++回调抛异常次数 */
    uint64_t wkc_bad;           /**< WKC不足周期数 */
    uint64_t worker_errors;     /**< 周期线程捕获的内部异常次数 */
    uint32_t tx_queue_level[4]; /**< 通道待发水位 */
    uint32_t credit[4];         /**< 最近有效TPDO返回的credit */
    uint32_t channel_state[4];  /**< 最近有效TPDO返回的通道位图 */
    uint32_t rx_queue_level;    /**< 等待回调的记录条数 */
    uint32_t reserved;          /**< 保留 */
} dmecat_stats_t;

/** @brief 调用线程最近一次API失败详情；SDO abort仅在实际读到时非0。 */
typedef struct
{
    uint32_t struct_size;       /**< 调用方结构大小 */
    int32_t code;               /**< DMECAT_ERR_* */
    uint32_t sdo_abort;         /**< 从后端错误信息提取的原始abort */
    char message[512];          /**< UTF-8，NUL结尾 */
} dmecat_error_t;
#pragma pack(pop)

/**
 * @brief 批量接收回调，运行在独立交付线程；frames仅在返回前有效。
 * @note 允许 submit/get_stats；禁止 start/stop/close/配置操作；调用方不得阻塞或抛异常。
 *       user_data由调用方持有，SDK不释放；stop返回后不再调用。
 */
typedef void (DMECAT_CALL *dmecat_rx_callback_t)(dmecat_device_t *device,
    const dmecat_frame_t *frames, uint32_t count, void *user_data);

/** @brief 获取SDK版本编码；不访问网卡。 @return 0xMMmmpp版本编码。 */
DMECAT_API uint32_t DMECAT_CALL dmecat_get_sdk_version(void) DMECAT_NOEXCEPT;
/** @brief 获取ABI主版本；不访问网卡。 @return ABI主版本，本版为1。 */
DMECAT_API uint32_t DMECAT_CALL dmecat_get_abi_version(void) DMECAT_NOEXCEPT;
/** @brief 查询本发行库编译的实际后端，不访问硬件。 @return SOEM或IGH。 */
DMECAT_API uint32_t DMECAT_CALL dmecat_get_backend(void) DMECAT_NOEXCEPT;
/** @brief 初始化默认后端、SM同步的扩展参数。 @param[out] options 输出，NULL时无操作。 */
DMECAT_API void DMECAT_CALL dmecat_init_open_options(dmecat_open_options_t *options) DMECAT_NOEXCEPT;
/** @brief 初始化默认1ms、每通道8帧、SM同步的打开参数。
 * @param[out] config 完整本版结构；NULL时无操作。
 */
DMECAT_API void DMECAT_CALL dmecat_init_open_config(dmecat_open_config_t *config) DMECAT_NOEXCEPT;
/** @brief 初始化80MHz时钟下1M@5M的CANFD位率参数。
 * @param[out] config 完整本版结构；NULL时无操作。
 */
DMECAT_API void DMECAT_CALL dmecat_init_baud_config(dmecat_baud_config_t *config) DMECAT_NOEXCEPT;
/** @brief 枚举网卡；NULL/0查询数量；不足时返回BUFFER，count总是所需条数。
 * @param[out] items 调用方数组，容量为0时可为NULL。
 * @param[in] capacity 数组元素容量。
 * @param[out] count 所需条数，必填。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_enum_adapters(dmecat_adapter_t *items,
    uint32_t capacity, uint32_t *count) DMECAT_NOEXCEPT;
/** @brief 打开、扫描并切PREOP/ECAT模式；不保存参数、不使能通道。失败时*out=NULL。
 * @param[in] config 经init_open_config初始化的打开参数。
 * @param[out] out SDK创建的句柄，调用方用close释放。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_open(const dmecat_open_config_t *config,
    dmecat_device_t **out) DMECAT_NOEXCEPT;
/**
 * @brief 按后端及SM/DC模式打开；旧open等价于默认后端、SM模式。
 * @param[in] config 基础配置；IgH的adapter为枚举所得/dev/EtherCAT<n>。
 * @param[in] options 扩展配置；DC仅允许125..1000us，必须支持DC。
 * @param[out] out 创建的句柄，失败时为NULL。
 * @return DMECAT_OK或DMECAT_ERR_*；平台不支持的后端返回NOT_SUPPORTED。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_open_ex(const dmecat_open_config_t *config,
    const dmecat_open_options_t *options, dmecat_device_t **out) DMECAT_NOEXCEPT;
/**
 * @brief 获取缓存的同步配置，不在周期线程外访问后端或发送SDO。
 * @param[in] device 有效设备句柄。
 * @param[in,out] out 调用前填写struct_size；首次start前回读字段为0。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_get_sync_status(dmecat_device_t *device,
    dmecat_sync_status_t *out) DMECAT_NOEXCEPT;
/** @brief 停止并销毁，成功后清空*device；NULL句柄可重复关闭。
 * @param[in,out] device 句柄指针；销毁后清空，即使退PREOP失败也可能已销毁。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_close(dmecat_device_t **device) DMECAT_NOEXCEPT;
/** @brief 获取扫描时缓存的设备信息，不在周期内发SDO。
 * @param[in] device 有效设备句柄。
 * @param[in,out] out 调用前填写struct_size的输出结构。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_get_device_info(dmecat_device_t *device,
    dmecat_device_info_t *out) DMECAT_NOEXCEPT;
/** @brief 停止态配置并提交指定通道；通道保持停止，需要显式使能。
 * @param[in] device 有效设备句柄。
 * @param[in] channel 通道号0..3。
 * @param[in] config 位率参数，struct_size必填。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_set_channel_baud(dmecat_device_t *device,
    uint32_t channel, const dmecat_baud_config_t *config) DMECAT_NOEXCEPT;
/** @brief 停止态读取生效位率；自动TDC回读硬件实际值，不保证等于写入的0。
 * @param[in] device 有效设备句柄。
 * @param[in] channel 通道号0..3。
 * @param[in,out] out 调用前填写struct_size的输出结构。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_get_channel_baud(dmecat_device_t *device,
    uint32_t channel, dmecat_baud_config_t *out) DMECAT_NOEXCEPT;
/** @brief 停止态使能/停止通道，enabled仅允许0/1。
 * @param[in] device 有效设备句柄。
 * @param[in] channel 通道号0..3。
 * @param[in] enabled 0停止，1使能。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_set_channel_enabled(dmecat_device_t *device,
    uint32_t channel, uint32_t enabled) DMECAT_NOEXCEPT;
/** @brief 停止态显式保存配置到设备参数区；open/start不会自动保存。
 * @param[in] device 有效设备句柄。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_save_config(dmecat_device_t *device) DMECAT_NOEXCEPT;
/** @brief 停止态显式复位从站会话。
 * @param[in] device 有效设备句柄。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_reset_session(dmecat_device_t *device) DMECAT_NOEXCEPT;
/** @brief 停止态设置接收回调；NULL明确表示不接收，相关条数计入rx_unhandled。
 * @param[in] device 有效设备句柄。
 * @param[in] callback 批量回调或NULL。
 * @param[in] user_data 调用方上下文，SDK不释放。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_set_rx_callback(dmecat_device_t *device,
    dmecat_rx_callback_t callback, void *user_data) DMECAT_NOEXCEPT;
/** @brief 清会话、配置SM/DC、进入OP并验证同步对象回读，启动周期与交付线程。
 * @param[in] device 已配置、处于停止态的设备句柄。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_start(dmecat_device_t *device) DMECAT_NOEXCEPT;
/** @brief 停止周期、取消本地待发帧、交付已接收帧、退PREOP；不承诺从站在途帧完成。
 * @param[in] device 有效设备句柄。
 * @return DMECAT_OK或DMECAT_ERR_*；重复停止安全，回调内禁止调用。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_stop(dmecat_device_t *device) DMECAT_NOEXCEPT;
/** @brief 提交单帧；成功仅表示SDK已复制入队，满队列返回QUEUE_FULL。
 * @param[in] device 正在运行的设备句柄。
 * @param[in] frame 输入帧，成功后调用方可立即重用。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_submit(dmecat_device_t *device,
    const dmecat_frame_t *frame) DMECAT_NOEXCEPT;
/** @brief 按数组前缀提交，accepted必填；失败时仅重试frames+accepted之后的剩余部分。
 * @param[in] device 正在运行的设备句柄。
 * @param[in] frames 输入帧数组，count为0时可为NULL。
 * @param[in] count 输入条数。
 * @param[out] accepted 本次成功入队的前缀条数，必填。
 * @return DMECAT_OK或DMECAT_ERR_*；非零返回也可能有成功前缀。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_submit_batch(dmecat_device_t *device,
    const dmecat_frame_t *frames, uint32_t count, uint32_t *accepted) DMECAT_NOEXCEPT;
/** @brief 获取本地统计快照，不发SDO；每次start重新计数。
 * @param[in] device 有效设备句柄。
 * @param[in,out] out 调用前填写struct_size的输出结构。
 * @return DMECAT_OK或DMECAT_ERR_*。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_get_stats(dmecat_device_t *device,
    dmecat_stats_t *out) DMECAT_NOEXCEPT;
/** @brief 复制当前调用线程最近一次失败详情，不因成功调用清除。
 * @param[in,out] out 调用前填写struct_size的输出结构。
 * @return DMECAT_OK或DMECAT_ERR_ARG。
 */
DMECAT_API dmecat_status_t DMECAT_CALL dmecat_get_last_error(dmecat_error_t *out) DMECAT_NOEXCEPT;

#ifdef __cplusplus
}
#endif
#endif
