/**
 * @file dmecat_export.h
 * @brief 公共 C 函数的符号可见性与调用约定。
 */
#ifndef DMECAT_EXPORT_H
#define DMECAT_EXPORT_H
#if defined(_WIN32)
#if defined(DMECAT_EXPORTS)
#define DMECAT_API __declspec(dllexport)
#else
#define DMECAT_API __declspec(dllimport)
#endif
#define DMECAT_CALL __cdecl
#else
#define DMECAT_API __attribute__((visibility("default")))
#define DMECAT_CALL
#endif
#ifdef __cplusplus
#define DMECAT_NOEXCEPT noexcept
#else
#define DMECAT_NOEXCEPT
#endif
#endif
