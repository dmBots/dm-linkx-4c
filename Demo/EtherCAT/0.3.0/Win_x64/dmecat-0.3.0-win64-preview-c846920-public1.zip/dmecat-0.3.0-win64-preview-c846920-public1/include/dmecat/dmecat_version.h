/**
 * @file dmecat_version.h
 * @brief dmecat SDK 版本号（单一真源）
 */
#ifndef DMECAT_VERSION_H
#define DMECAT_VERSION_H

#define DMECAT_VERSION_MAJOR 0
#define DMECAT_VERSION_MINOR 3
#define DMECAT_VERSION_PATCH 0

/** @brief 公共 C ABI 主版本；与 SDK 及 PDO 协议版本独立。 */
#define DMECAT_ABI_VERSION 1u

/** @brief 版本号编码为 0xMMmmpp（与同族 SDK 的 get_sdk_version 口径一致） */
#define DMECAT_VERSION_CODE ((DMECAT_VERSION_MAJOR << 16) | (DMECAT_VERSION_MINOR << 8) | DMECAT_VERSION_PATCH)

#endif /* DMECAT_VERSION_H */
