"""@file verify_sdk_archive.py
@brief 在内存中核对发布归档的真实字节，避免透明加密让解包后的本机验证产生假象。
"""
import hashlib
import sys
import tarfile
import zipfile


def main():
    """@brief 不解包、不改文件，逐条验证归档内SHA256及公共头为可读源码。"""
    path = sys.argv[1]
    is_zip = zipfile.is_zipfile(path)
    with zipfile.ZipFile(path) if is_zip else tarfile.open(path, "r:gz") as archive:
        names = archive.namelist() if is_zip else archive.getnames()
        manifests = [name for name in names if name.split("/")[-1] == "SHA256SUMS.txt"]
        if len(manifests) != 1:
            raise ValueError("归档必须只有一份SHA256清单")
        prefix = manifests[0][:-len("SHA256SUMS.txt")]

        def read(name):
            """@brief 直接读取归档成员字节；tar中的库链接由tarfile解析。"""
            if is_zip:
                return archive.read(name)
            with archive.extractfile(name) as stream:
                return stream.read()

        lines = read(manifests[0]).decode("utf-8").splitlines()
        for line in lines:
            expected, relative = line.split("  ", 1)
            actual = hashlib.sha256(read(prefix + relative)).hexdigest()
            if actual != expected:
                raise ValueError("归档字节SHA256不符: " + relative)
        header = read(prefix + "include/dmecat/dmecat.h")
        if not header.startswith(b"/**"):
            raise ValueError("公共头不是可读源码，不能发布保护层存储字节")
        print(f"PASS: {len(lines)} archive members match SHA256; public header is plaintext")


if __name__ == "__main__":
    main()
