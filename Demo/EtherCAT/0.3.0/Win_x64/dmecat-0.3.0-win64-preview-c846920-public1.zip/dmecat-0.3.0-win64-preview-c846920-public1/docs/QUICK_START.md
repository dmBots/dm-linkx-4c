# SDK 0.3.0 快速入门

按本文完成依赖安装、示例编译、网卡枚举和第一次收发。当前为预览版，存在已知数据完整性限制；接入前请阅读 [已知问题](KNOWN_ISSUES.md)。首次使用默认 SM / 1ms，只有需要 DC-SYNC0 时才显式选择 DC。

## 1. 准备环境

使用同一发行包内的头文件、库和示例，并确认从站固件支持 PDO v8。不要混用历史 Demo 或其他平台的后端库。

- Windows x64：安装 Npcap 的 WinPcap API 兼容支持和 MSVC x64 Release 运行时。本包提供 `bin/x64/dmecat.dll` 和独立 `soem.dll`，只支持 SOEM 2.0.0；不要替换为其他版本。Npcap 不随 SDK 分发，打开网卡的权限取决于安装策略。
- Linux x86_64：安装 IgH 1.5.4 / API 1.5 用户态库和匹配的内核模块，完成主站网卡配置，并取得目标 `/dev/EtherCAT<n>` 的读写权限。不需要安装 Windows 的 SOEM/Npcap。

文件完整性可用包内工具检查：

```text
python -B <SDK解压目录>/tools/verify_sdk_archive.py <下载的zip或tar.gz>
```

## 2. 编译示例并枚举

### Windows x64

准备 MSVC C/C++ 工具链、CMake 和 Ninja。在 **x64 Native Tools Command Prompt** 中执行，将路径替换为自己的解压目录：

```bat
chcp 65001
set "DMECAT_SDK_DIR=C:\sdk\linkx4c-ethercat"
cmake -S "%DMECAT_SDK_DIR%\examples" -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=cl -DCMAKE_CXX_COMPILER=cl -DCMAKE_PREFIX_PATH="%DMECAT_SDK_DIR%"
cmake --build build
copy "%DMECAT_SDK_DIR%\bin\x64\dmecat.dll" build\
copy "%DMECAT_SDK_DIR%\bin\x64\soem.dll" build\
build\example_cpp.exe --list
```

### Linux x86_64

准备 C/C++ 工具链和 CMake。下面以 SDK 库目录为 `lib`、IgH 安装前缀为 `/opt/etherlab` 为例；实际使用 `lib64` 或其他前缀时请对应替换：

```sh
export DMECAT_SDK_DIR=/path/to/linkx4c-ethercat
cmake -S "$DMECAT_SDK_DIR/examples" -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$DMECAT_SDK_DIR" -DDMECAT_IGH_ROOT=/opt/etherlab
cmake --build build
LD_LIBRARY_PATH="$DMECAT_SDK_DIR/lib:/opt/etherlab/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ./build/example_cpp --list
```

应用不需要 SOEM/IgH 头文件。非默认前缀通过 `DMECAT_IGH_ROOT` 指定；运行时须同时找到 SDK 和 IgH 动态库。

`--list` 只枚举，不打开从站、不切换模式、不发送 CAN。枚举成功不代表有打开权限。若程序在 API 调用前加载失败，请先检查架构、依赖和动态库搜索路径，此时 `get_last_error` 未必能提供信息。

## 3. 第一次收发

**以下操作会切换设备到 ECAT 模式、修改本次 CAN 配置并发送帧。请使用独立测试总线，不要直接在业务总线上运行。**

先确认目标网口未被 TwinCAT、其他主站或另一个程序占用。将 **CH0 与 CH1** 接通，确认共地、终端电阻和位率匹配。这不是控制器内部回环；与其他节点通信时，需要正常应答节点。

Windows 使用 `--list` 返回的完整网卡路径：

```bat
build\example_cpp.exe "\Device\NPF_{替换为枚举所得GUID}"
```

Linux 使用枚举所得设备路径，并保持动态库路径设置：

```sh
LD_LIBRARY_PATH="$DMECAT_SDK_DIR/lib:/opt/etherlab/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ./build/example_cpp /dev/EtherCAT0
```

C++ 示例默认 CAN FD 仲裁段 1 Mbps / 数据段 5 Mbps、BRS、DLC=8、SM / 1ms，由 CH0 发、CH1 收。每轮发送 8 帧并核对 ID、接收通道、DLC 和完整载荷，停止后在同一句柄再跑一轮。每轮应显示 `received=8/8 valid=yes` 且退出码为 0；错误或缺帧返回非零。这只能证明该次示例结果，不代表高负载无损或长期稳定性通过。

确需 DC-SYNC0 时，在上述收发命令末尾加 `--dc`，首次仍使用 1ms；不要因普通收发失败自动改同步模式。

## 4. 接入应用

CMake 使用 `find_package(dmecat CONFIG REQUIRED)`，应用链接 `dmecat::dmecat` 并包含 `dmecat/dmecat.h`。完整配置和帧构造见 [SDK README](../README.md)；调用顺序如下，函数名均加 `dmecat_` 前缀：

```text
enum_adapters → init_open_config + init_open_options → 填写adapter → open_ex
→ set_channel_baud / get_channel_baud → set_channel_enabled
→ set_rx_callback → start → submit / submit_batch + get_stats / get_sync_status
→ 停止业务生产者 → stop → 可重新配置/start → close(&handle)
```

- `open_ex` 会切换模式和 AL 状态，但不自动使能 CAN。配置和回调注册须在 STOPPED；配置位率会停止对应通道，之后必须显式使能。
- 使用初始化函数设置配置默认值；其他带 `struct_size` 的输出先清零，再填 `sizeof`。通道编号为 `0..3`，DLC 是编码，不是数据字节数。
- 兼容固件可能延后应用配置，示例的 1100ms 等待不是通用完成通知，也不解决已知缺帧问题。自动 TDC 回读可能为硬件实际值，而不是写入的 0。
- SDK 管理周期线程和接收交付线程，应用不用再驱动 EtherCAT 循环。回调中不要长时间阻塞或抛异常；帧指针仅在回调期间有效，需要保留就复制。
- 回调可提交帧、读统计和同步缓存，不能对本句柄 start/stop/close/配置或更换回调。上下文及 C# 委托须存活到 stop 成功返回；close 前停止其他线程访问句柄。
- 每通道 FIFO 满时保留旧帧、拒绝新帧。`submit_batch` 返回错误也可能已有成功前缀，必须检查 `accepted`，只重试未接纳后缀，避免忙等或重复发送前缀。
- `submit` 成功仅代表本地入队，`tx_submitted` 不是 CAN 完成计数，`stop` 不是 flush。需要端到端确认时，应核对实际接收/应答和完整内容。
- 失败后同线程立即调用 `get_last_error`；异步错误和背压读 `get_stats`。FAULTED 后先 stop 回收资源，再决定是否重启。

`open` 使用默认后端及 SM；`open_ex` 可显式选择同步模式。DC 周期为 125..1000us、相移绝对值小于周期，并须满足 `0 < rx_timeout_us < period_us`；改同步模式需要关闭后重开。`get_sync_status.active` 不代表 DC_LOCKED、相位精度或 CAN 交付，Windows 不保证硬实时。

仅在需要持久化时显式调用 `save_config`；普通 open/start 不保存参数、不恢复出厂、不烧录固件。结构布局、线程和计数语义见 [ABI 参考](ABI_V1.md)，支持范围见 [版本说明](RELEASE_NOTES.md)。
