# LinkX4C SDK 公共 C ABI 1 参考

本文用于 C/C++ 调用及 C# 等跨语言绑定。适用 SDK 0.3.0 / ABI 1：Windows x64 使用独立 SOEM 2.0.0 动态库，Linux x86_64 使用 IgH 1.5.4 / API 1.5。支持单网卡/主站、单台 LinkX4C、四通道和 PDO v8；默认 SM，可显式选择 DC-SYNC0。不能跨平台混用后端，Windows 普通调度不保证硬实时。

应用包含 `include/dmecat/dmecat.h`，链接同包 SDK 库；C++ 应用也使用这组 C 接口，不需要 SOEM/IgH 头文件。跨语言绑定须保持下列结构布局和调用约定。完整收发示例见 `examples/basic.cpp`，部署步骤见 [快速入门](QUICK_START.md)。

## 1. ABI 规则

- C linkage、`__cdecl`；`int32_t` 错误码、定宽整数和不透明指针；没有 STL、C++ 异常、引用、`bool` 或枚举类型跨边界。
- 所有结构 `pack=8`，不能用 `pack=1`。帧数组步长固定 88B，是应用内存布局，不是线上序列化格式。
- 带 `struct_size` 的输入/输出，调用前填当前头文件的 `sizeof`；open 另需 ABI 版本 1。使用初始化函数设置配置默认值，其他结构先清零再填大小，保留字段保持零。不要自行修改字段、打包方式或帧数组步长来适配其他版本。
- SDK 内分配的句柄仅由 `dmecat_close` 销毁；帧提交时复制，用户可立即重用输入数组；枚举、输出与错误信息均写入调用方缓冲。
- API 通过错误码报告失败，不向应用抛出 C++ 异常。周期线程异常计入 `worker_errors`，状态变为 FAULTED，后续提交返回 IO；先 stop 回收资源，再决定是否重启。应用回调不得抛异常，不能依赖跨动态库异常传播。

## 2. 固定布局

| 结构 | 大小/B | 关键偏移/B |
| --- | ---: | --- |
| `dmecat_frame_t` | 88 | timestamp=0，CAN ID=8，channel=12，seq=22，payload=24 |
| `dmecat_adapter_t` | 1024 | name=0，description=512 |
| `dmecat_open_config_t` | 576 | adapter=8，slave=520，reserved=544 |
| `dmecat_baud_config_t` | 32 | enable_canfd=4，nominal_brp=8 |
| `dmecat_device_info_t` | 40 | vendor_id=12，pdo_protocol=28 |
| `dmecat_stats_t` | 160 | tx_enqueued=8，worker_errors=96，tx_queue_level=104 |
| `dmecat_error_t` | 524 | code=4，sdo_abort=8，message=12 |
| `dmecat_open_options_t` | 32 | backend=4，sync_mode=8，dc_shift_ns=12 |
| `dmecat_sync_status_t` | 32 | backend=4，active=12，period_ns=24 |

`dlc` 是 DLC 编码，不是数据字节数；`dlen` 是有效字节数。FD 的 DLC=9..15 对应 12/16/20/24/32/48/64B；经典 CAN DLC≤8；RTR 不携带数据，不能与 FD 同用。发送时 ESI、seq、reserved0 填零。本版SM/DC接入示例均即时收发，应设置 `ts_valid=0`、`timestamp_us=0`；DC模式选择不等于已验证定时CAN发送。

## 3. 生命周期和线程

```text
枚举 → 初始化配置 → open或open_ex（切换ECAT模式并进入PREOP）
     → 配置位率 → 显式使能通道 → 注册接收回调
     → start（验证同步配置、进入OP并启动通信；成功后才可提交帧）
     → submit/submit_batch + get_stats
     → stop（停周期、取消本地待发、排空已接纳回调、退PREOP）
     → 可重新配置/start，或close（清空调用方句柄）
```

open/start 不自动保存配置、不恢复出厂、不烧录固件；open 不自动使能 CAN 通道，保存仅由显式 `save_config` 触发。位率配置会停止相应 CAN 通道，之后要显式使能。

`get_channel_baud` 用于回读位率配置；自动 TDC 的 offset/filter 可能回读硬件实际值，而不是写入的 0。配置可能延后应用，回读成功不替代实际收发验证，详见 [已知问题](KNOWN_ISSUES.md)。

同一句柄支持多线程提交与读取统计。生命周期/配置操作须串行，配置和回调注册仅允许 STOPPED。停止期间状态为 STOPPING；并发生命周期操作可能返回 STATE。close 前调用方必须停止其他线程访问该句柄，不能并发 close，也不能使用已释放句柄。空句柄重复 close 安全。

SDK 为每个句柄管理周期线程和交付线程，应用不需要再驱动 EtherCAT 循环。提交不改变周期节拍，没有待发 CAN 帧时也保持必要通信。1ms 是配置目标，不是主机调度抖动保证。

接收回调运行于独立交付线程，不能长时间阻塞。允许对本句柄 submit/get_stats/get_sync_status；禁止对本句柄 start/stop/close/配置或更换回调，否则返回 CALLBACK。frames 指针仅在回调返回前有效，需长期保存时自行复制。`user_data` 生命周期至少覆盖到 stop 成功返回；此后不再回调，close 后才可卸载动态库。C# 必须持有委托和用户上下文，不能让 GC 提前回收。

## 4. 队列、聚合和背压

应用以 `frame.channel` 选择通道，SDK 分别排队并保留各通道 FIFO；跨通道不保证全局提交顺序。SDK 根据周期字节预算、设备 credit 和每通道配额，以 round robin 聚合。应用不装配 PDO、不管理 credit，也不能把配额当作每拍实际发送保证。

TX 每通道容量默认 256、可设 16..65536，向上取整到 2 的幂。队列满时拒绝新帧、保留旧帧，不隐式丢最老帧、不无限阻塞。返回 QUEUE_FULL；`submit_batch` 总是写入 `accepted`（必填），只重试剩余后缀，不能重放已成功前缀。提交成功仅表示本地已复制，不代表 EtherCAT 从站接纳或 CAN 真上线完成。

RX 默认 4096 帧，可设 80..65536。接收窗口整体入队；空间不足时不部分接纳该窗口，并产生接收背压。SDK 接纳数据不等于应用已处理或持久化；队列有界不保证慢消费者下物理 CAN 永不丢帧。未注册回调时，帧会被消费并计入 `rx_unhandled`，不能稍后通过同步读取取回。

stop 不是 flush：本地未提交帧取消并计数；已经交给从站的在途 CAN 帧不承诺完成。需要应用级交付保证时，由业务侧做对账，不能把 stop 当作总线发送完成屏障。

## 5. 接口清单（24 个导出）

| 类别 | 接口 |
| --- | --- |
| 版本/初始化 | get_sdk_version、get_abi_version、init_open_config、init_baud_config |
| 发现/句柄 | enum_adapters、open、close、get_device_info |
| 配置 | set_channel_baud、get_channel_baud、set_channel_enabled、save_config、reset_session |
| 数据 | set_rx_callback、start、stop、submit、submit_batch |
| 诊断 | get_stats、get_last_error |
| 0.3.0新增 | get_backend、init_open_options、open_ex、get_sync_status |

以上统一加 `dmecat_` 前缀。枚举用 NULL/0 查询容量，不足返回 BUFFER，同时 count 返回所需条数。

0.2.0的20个接口和既有布局不变；新应用使用0.3.0的4个新增接口时必须部署相应新版库，不能用旧DLL补齐新符号。`open_ex`的options必须经初始化，DEFAULT后端解析为本发行库实际后端（SOEM=1、IgH=2），请求其他平台后端返回NOT_SUPPORTED；旧open保持默认SM行为。

DC 仅接受 125..1000us、相移绝对值小于周期，且须满足 `0 < rx_timeout_us < period_us`。首次使用建议 1ms；缩短周期时须同时调整接收超时。同步模式在打开时选择，更改需要 close 后重新 open_ex。start 同步验证失败会返回错误，不进入运行态。

`get_sync_status` 是线程安全的缓存快照。active 表示同步配置验证后处于运行态，不是 DC_LOCKED、同步误差或 CAN 完成计数。首次 start 前同步类型为 0；停止后保留上次回读，但 active=0。应用无需自行配置从站同步对象。

主要本地错误：ARG=101、NOT_SUPPORTED=102、IO=103、QUEUE_FULL=104、STATE=105、DEPENDENCY=106、NO_MEMORY=107、BUFFER=108、CALLBACK=109。0..9 保留当前协议错误值。

last_error 按调用线程保存；成功 API 不清除最近一次失败。失败后在同一线程调用 `get_last_error`，SDO abort 只有后端实际取得时才非零。异步周期异常通过统计报告，不伪装为调用线程的最近错误。

## 6. 计数口径

每次成功 start 重置统计，读取时须区分提交、交付和实际总线完成：

| 计数 | 含义 |
| --- | --- |
| `tx_enqueued` | 已复制到本地发送队列的帧数 |
| `tx_submitted` | WKC 达标后出队的帧数，**不是 CAN TX-complete** |
| `tx_cancelled` | stop 取消的本地待发帧数 |
| `rx_queued` | SDK 整体接纳接收窗口的帧数 |
| `rx_delivered` | 回调正常返回的帧数 |
| `rx_unhandled` | 未注册回调而被消费的帧数 |
| `rx_backpressure` | 接收窗口因空间不足暂未接纳的次数 |
| `callback_errors` | 回调抛异常的次数；应用仍不得抛异常 |
| `worker_errors` | 周期线程异常退出次数 |

`rx_queued` 不保证等于 `rx_delivered`，还要考虑未注册回调和异常回调。可靠交付应由应用按实际接收/应答核对，不应仅比较 SDK 发送和接收计数。

## 7. 相关资料

- 函数签名与字段定义以同包公共头为准；`examples/` 提供 C/C++ 调用与 C# 布局示例。已知限制见 [已知问题](KNOWN_ISSUES.md)，支持平台与验证范围见 [版本说明](RELEASE_NOTES.md)。
- Microsoft：[跨 DLL 边界传递 CRT 对象的注意事项](https://learn.microsoft.com/en-us/cpp/c-runtime-library/potential-errors-passing-crt-objects-across-dll-boundaries?view=msvc-170)，对应本版不跨库传 STL/CRT 对象与分配释放配对规则。
- SOEM 官方 [v2.0.0 CMakeLists](https://github.com/OpenEtherCATsociety/SOEM/blob/v2.0.0/CMakeLists.txt) 与 [LICENSE.md](https://github.com/OpenEtherCATsociety/SOEM/blob/v2.0.0/LICENSE.md)。
