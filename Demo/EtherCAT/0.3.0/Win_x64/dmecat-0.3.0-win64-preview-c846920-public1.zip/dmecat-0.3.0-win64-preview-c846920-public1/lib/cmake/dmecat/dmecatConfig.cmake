include("${CMAKE_CURRENT_LIST_DIR}/dmecatTargets.cmake")
if(NOT WIN32)
    # 应用只链接SDK目标；在用户机器查找IgH，不能硬编码构建台架的绝对路径。
    find_library(DMECAT_IGH_RUNTIME_LIBRARY NAMES ethercat
        HINTS "${DMECAT_IGH_ROOT}/lib" /opt/etherlab/lib)
    if(NOT DMECAT_IGH_RUNTIME_LIBRARY)
        set(dmecat_FOUND FALSE)
        set(dmecat_NOT_FOUND_MESSAGE "缺少IgH用户态动态库libethercat，请先安装或指定DMECAT_IGH_ROOT")
        return()
    endif()
    set_property(TARGET dmecat::dmecat APPEND PROPERTY INTERFACE_LINK_LIBRARIES
        "${DMECAT_IGH_RUNTIME_LIBRARY}")
endif()
