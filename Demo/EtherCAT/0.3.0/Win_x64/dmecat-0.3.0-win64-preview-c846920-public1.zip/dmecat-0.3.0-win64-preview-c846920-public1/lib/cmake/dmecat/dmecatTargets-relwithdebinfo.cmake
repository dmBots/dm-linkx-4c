#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dmecat::dmecat" for configuration "RelWithDebInfo"
set_property(TARGET dmecat::dmecat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(dmecat::dmecat PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/x64/dmecat.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/x64/dmecat.dll"
  )

list(APPEND _cmake_import_check_targets dmecat::dmecat )
list(APPEND _cmake_import_check_files_for_dmecat::dmecat "${_IMPORT_PREFIX}/lib/x64/dmecat.lib" "${_IMPORT_PREFIX}/bin/x64/dmecat.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
