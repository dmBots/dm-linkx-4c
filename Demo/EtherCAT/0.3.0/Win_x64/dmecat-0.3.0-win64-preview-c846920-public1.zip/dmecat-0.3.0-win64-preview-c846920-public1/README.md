# LinkX4C EtherCAT SDK

在自己的 C、C++ 或 C# 应用中，通过 EtherCAT 使用 LinkX4C 的四路 CAN / CAN FD。应用提交普通 CAN 帧并接收批量回调；SDK 负责周期通信、按通道排队、聚合、协议封装和参数下发，应用不需要直接操作 SOEM、IgH 或 PDO。

当前版本：**SDK 0.3.0 预览版 / C ABI 1**。已有缺帧、错载荷及 WKC 不足记录，尚未通过生产无损或长期稳定性验收。接入前请阅读 [已知问题](docs/KNOWN_ISSUES.md)，不要把示例跑通当作生产验收通过。

## 1. 选择适合你的包

| 项目 | Windows 包 | Linux 包 |
| --- | --- | --- |
| 平台 | Windows x64 | Linux x86_64 |
| SDK 运行库 | `bin/x64/dmecat.dll` | `lib/libdmecat.so.1`（部分安装为 `lib64`） |
| 后端 | 独立动态链接 **SOEM 2.0.0**；其他 SOEM 版本不支持 | 动态链接 IgH，要求 **1.5.4 / API 1.5** |
| 另行准备 | Npcap、MSVC x64 Release 运行时 | 匹配的 IgH 用户态库、内核模块及主站网卡配置 |
| 设备名称 | SDK 枚举返回的完整 `\Device\NPF_{...}` 路径 | SDK 枚举返回的 `/dev/EtherCAT<n>` |

当前支持单网卡/主站、单台 LinkX4C、4 个 CAN 通道（`0..3`），PDO v8（下行 1328B / 上行 1304B）。两平台使用相同公共 C API；不是在一个 DLL 中任意切换平台后端。

使用发行包即可接入，不需要 SDK 源码、Npcap SDK、SOEM/IgH 头文件或 SOEM 导入库。C# 目前只有 ABI 加载示例，不是完整托管业务封装。

| 包内入口 | 用途 |
| --- | --- |
| `include/dmecat/dmecat.h` | 唯一公共 API 入口，C/C++ 均可使用 |
| `lib/cmake/dmecat/` | CMake 接入目标 `dmecat::dmecat` |
| `examples/basic.c` / `basic.cpp` | 最小调用 / 完整收发核对及同句柄重启 |
| `examples/csharp/` | C# 结构布局与动态库加载示例 |
| `manifest.json` / `SHA256SUMS.txt` | 包的版本、源码提交、平台、依赖与文件校验 |
| `skills/dmecat-sdk-consumer/` | 配套 AI Skill，帮助 AI 在应用侧正确接入 |

首次接入时，请使用同一发行包的头文件和动态库，不要与旧版 SDK 或历史 Demo 混用。版本、平台和依赖信息见 `manifest.json`，文件完整性可按 `SHA256SUMS.txt` 校验。

## 2. 安装后先做不发帧检查

先核对 `manifest.json` 的版本、平台、后端及源码提交。可使用 Python 直接验证下载归档的真实字节：

```text
python -B <SDK目录>/tools/verify_sdk_archive.py <下载的zip或tar.gz>
```

Windows：安装 Npcap 的 WinPcap API 兼容支持及 MSVC x64 Release 运行时。将本包 `dmecat.dll`、`soem.dll` 放在应用可执行文件目录。Npcap 不随包分发；打开权限取决于安装策略，不是只要能枚举就一定能打开。

在 **x64 Native Tools Command Prompt** 中执行（替换为你的解压目录；需要 CMake 和 Ninja）：

```bat
chcp 65001
set "DMECAT_SDK_DIR=C:\sdk\linkx4c-ethercat"
cmake -S "%DMECAT_SDK_DIR%\examples" -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=cl -DCMAKE_CXX_COMPILER=cl -DCMAKE_PREFIX_PATH="%DMECAT_SDK_DIR%"
cmake --build build
copy "%DMECAT_SDK_DIR%\bin\x64\dmecat.dll" build\
copy "%DMECAT_SDK_DIR%\bin\x64\soem.dll" build\
build\example_cpp.exe --list
```

Linux：由部署方安装、配置 IgH，确保目标 `/dev/EtherCAT<n>` 的读写权限。不要用 Windows 的 NPF 路径。以下以包中库目录为 `lib`、IgH 安装在 `/opt/etherlab` 为例；实际为 `lib64` 或其他前缀时请替换：

```sh
export DMECAT_SDK_DIR=/path/to/linkx4c-ethercat
cmake -S "$DMECAT_SDK_DIR/examples" -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$DMECAT_SDK_DIR" -DDMECAT_IGH_ROOT=/opt/etherlab
cmake --build build
LD_LIBRARY_PATH="$DMECAT_SDK_DIR/lib:/opt/etherlab/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ./build/example_cpp --list
```

`--list` 只枚举，不打开从站、不切换模式、不发 CAN。DLL/共享库加载错误先处理依赖和搜索路径；系统加载器可能在调用 SDK API 前就失败，此时不能依靠 `dmecat_get_last_error` 获取信息。

## 3. 第一次实际收发

先确认目标网口独占，没有 TwinCAT、其他主站或另一个程序占用；CAN 接线、共地、终端电阻和位率匹配。**带设备路径运行示例会修改本次设备配置并发送 CAN，不要在业务总线上随意运行。**

本包 C++ 示例的接线为 **CH0 ↔ CH1**：CH0 发、CH1 收，CAN FD 仲裁段 1 Mbps / 数据段 5 Mbps、BRS、DLC=8。不是控制器内部回环，也不保证发送帧在原发送通道产生本地 echo。与其他 CAN 节点通信时，需有正常应答节点。

Windows 使用 `--list` 返回的完整路径（保留引号）：

```bat
build\example_cpp.exe "\Device\NPF_{替换为枚举所得GUID}"
```

Linux（同样设置动态库搜索路径）：

```sh
LD_LIBRARY_PATH="$DMECAT_SDK_DIR/lib:/opt/etherlab/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ./build/example_cpp /dev/EtherCAT0
```

默认使用 SM / 1 ms。C++ 示例每轮发送 8 帧，核对 ID、接收通道、DLC 和全载荷，`stop` 后在同一句柄再跑一轮；每轮应为 `received=8/8 valid=yes`，进程返回 0。退出成功仍不代表高负载无损通过。完整实现见 [C++ 示例](examples/basic.cpp)，简化版本见 [C 示例](examples/basic.c)。

只有明确要测 DC-SYNC0 时才在相同命令末尾加 `--dc`，首次仍使用 1 ms。不要因收发失败自动改用 DC 或反复抢占设备。

## 4. 接入自己的应用

CMake 项目只链接 SDK 的公开目标，不创建 SOEM/IgH 上下文：

```cmake
cmake_minimum_required(VERSION 3.20)
project(my_can_app LANGUAGES C)
set(CMAKE_C_STANDARD 11)
find_package(dmecat CONFIG REQUIRED)
add_executable(my_can_app main.c)
target_link_libraries(my_can_app PRIVATE dmecat::dmecat)
if(MSVC)
    target_compile_options(my_can_app PRIVATE /utf-8)
endif()
```

配置项目时传 `-DCMAKE_PREFIX_PATH=<SDK目录>`。非 CMake 的 Windows 项目添加 `include` 搜索路径并链接 `lib/x64/dmecat.lib`，运行时仍需两个 DLL。Linux 项目链接 SDK 共享库并配置动态依赖路径。仅使用包内公共头，不要替换或静态合入其他 SOEM 版本。

### 生命周期

1. `dmecat_enum_adapters` 选择目标路径；`dmecat_init_open_config`、`dmecat_init_open_options` 初始化配置，复制完整路径到 `config.adapter`。
2. `dmecat_open_ex` 扫描、进入 PREOP、通过 SDO 切 ECAT 模式并回读。**open 不是只读操作**，但不保存参数、不自动使能 CAN。
3. 停止态调用 `dmecat_init_baud_config`、`dmecat_set_channel_baud` / `dmecat_get_channel_baud`，再 `dmecat_set_channel_enabled`。默认位率是 CAN FD 1M@5M，BRS 按帧选择；配置位率会停对应通道，之后必须显式使能。
4. `dmecat_set_rx_callback` 注册回调，再 `dmecat_start`。start 负责同步配置、进入 OP 及启动内部线程；成功后才能提交帧。
5. 业务线程调用 `dmecat_submit` / `dmecat_submit_batch`，接收走回调；运行诊断用 `dmecat_get_stats` / `dmecat_get_sync_status`。
6. 停止业务生产者，调用 `dmecat_stop`，需要时在同一句柄重新配置/start；最终 `dmecat_close(&device)`。close 前停止其他线程访问句柄，之后才能卸载库。

初始化函数负责 `struct_size`、ABI 和默认值；其他带 `struct_size` 的输出结构先清零，再填 `sizeof(结构)`；保留字段保持 0。`get_device_info.revision` 是 SII 修订号，**不是固件构建版本**。

兼容固件可能延后应用 CAN 配置，包内示例保留 1100 ms 稳定等待；这是已知兼容措施，不是通用配置完成通知。自动 TDC 回读也可能是硬件实际值，而不是写入的 0。配置保存仅由显式 `dmecat_save_config` 触发，不需要持久化就不要调用。

### 构造发送帧

下面函数用于**已配置并 start 成功的句柄**，提交 CH0、标准 ID `0x123`、CAN FD+BRS、8B 数据；其余数据字节为 0：

```c
#include <dmecat/dmecat.h>

/** @brief 提交一帧CANFD；成功只代表SDK已复制入队，不代表CAN发送完成。
 * @param[in] device 已配置CH0且start成功的句柄。
 * @return DMECAT_OK或具体错误码，调用者负责处理背压与失败。
 */
dmecat_status_t send_canfd8(dmecat_device_t *device)
{
    dmecat_frame_t frame = {0};
    frame.channel = 0;
    frame.can_id = 0x123;
    frame.fdf = 1;
    frame.brs = 1;
    frame.dlc = 8;
    frame.dlen = 8;
    frame.payload[0] = 0x11;
    frame.payload[1] = 0x22;
    return dmecat_submit(device, &frame);
}
```

| 字段 | 使用规则 |
| --- | --- |
| `channel` | `0..3` 选择对应通道，不能用 1..4 编号 |
| `can_id` / `ide` | 标准 ID≤`0x7FF`；扩展帧设 `ide=1`，ID≤`0x1FFFFFFF` |
| `dlc` / `dlen` | DLC 是编码，不是字节数；0..8 对应 0..8B，9..15 对应 12/16/20/24/32/48/64B |
| `fdf` / `brs` | CAN FD 设 `fdf=1`，需要数据段变速再设 `brs=1`；经典 CAN 二者为 0、DLC≤8 |
| `rtr` | 经典远程帧设 1，`dlen=0`；不能与 CAN FD 同用 |
| `timestamp_us` / `ts_valid` | 本版入门使用即时发送，二者为 0；DC 不等于已验证定时 CAN 发送 |
| `esi` / `seq` / `reserved0` | 发送时填 0，不把 `seq` 当业务序号 |

`dmecat_frame_t` 是 **pack=8、88B 的内存结构**，不是 PDO 线格式。批量发送必须检查 `accepted`：即使返回错误，也可能已有成功前缀；只保留/重试 `frames + accepted` 的剩余部分，不能整批重发。实现见 `basic.cpp` 的 `exchange`。

### 队列与回调

- SDK 按 `frame.channel` 放入每通道 FIFO，按字节预算、从站 credit、配额和 round robin 聚合。应用不自己装 PDO 或管理 ACK/credit；跨通道不保证全局提交顺序。
- TX 默认 256 帧/通道；满时**保留旧帧、拒绝新帧**，返回 `DMECAT_ERR_QUEUE_FULL`。SDK 不丢最老帧、不无限阻塞；应用决定限流、等待重试或放弃未接纳部分，避免忙等。
- SDK 自起周期线程和交付线程，使用条件变量等待。业务方不需要另起 EtherCAT 轮询循环，空闲时 SDK 仍保持必要的周期通信。
- 接收回调运行在交付线程，不是 UI 线程。不要长时间阻塞、同步写盘或抛异常；`frames` 仅在回调返回前有效，需要保留就复制到应用自己的有界队列，再通知业务线程。
- 回调内允许 submit/读统计/读同步缓存；禁止本句柄 start、stop、close、重配通道或更换回调。`user_data`、C# 委托等至少存活到 stop 成功返回。
- 不注册回调时，帧会被消费并计入 `rx_unhandled`，不是留给后续轮询读取。当前无同步阻塞收帧 API。
- RX 默认 4096 帧，整窗接纳；满时不部分入队、不推进该窗 ACK。不能保证无限慢消费者下物理 CAN 永不丢帧。

## 5. SM / DC 与参数边界

默认参数为 SM、1000 µs、每通道每拍最多 8 帧、TX 256/通道、RX 4096、接收超时 500 µs。`frames_per_ch` 是配额上限，不是保证每拍送到总线的数量。

需要 DC 时，在 `open_ex` 前将初始化后的 `options.sync_mode` 设为 `DMECAT_SYNC_DC`，`config.period_us=1000`，`options.dc_shift_ns=0`。DC 周期 125..1000 µs、相移绝对值小于周期；改周期还须满足 `0 < rx_timeout_us < period_us`。较短周期不代表已通过该档性能验收。

后端默认使用当前发行库的平台后端。请求不支持的后端返回 `NOT_SUPPORTED`，不悄悄切换。SM/DC 在打开时选择，改模式需关闭后重新 `open_ex`。`get_sync_status.active=1` 仅表示配置验证后正在运行，**不是 DC_LOCKED、相位精度或 CAN 交付保证**；Windows 普通调度不保证硬实时。

## 6. 错误处理与排查

检查每个返回值是否为 `DMECAT_OK`。失败后在**同一调用线程**立即取错误，不能用成功调用后的旧错误判断本次结果：

```c
#include <dmecat/dmecat.h>
#include <stdio.h>

/** @brief 在API失败的同一线程输出错误；成功调用不清除最近失败详情。
 * @param[in] status 本次API返回值。
 */
void report_sdk_error(dmecat_status_t status)
{
    if (status != DMECAT_OK)
    {
        dmecat_error_t error = {0};
        error.struct_size = sizeof(error);
        if (dmecat_get_last_error(&error) == DMECAT_OK)
        {
            fprintf(stderr, "status=%d error=%s sdo_abort=0x%08X\n",
                (int)status, error.message, (unsigned)error.sdo_abort);
        }
    }
}
```

| 现象 / 错误 | 优先检查 |
| --- | --- |
| 程序无法加载 | x64架构、两DLL/IgH库、Npcap/MSVC运行时、动态库搜索路径 |
| `DEPENDENCY` | SOEM 必须为本包支持的 2.0.0，不随意替换 |
| `VERSION` / `ARG` | 头与库版本、struct_size、保留0、通道/帧字段、PDO v8匹配 |
| `STATE` / `CALLBACK` | 是否start成功、是否停止态配置、是否回调内操作生命周期 |
| `QUEUE_FULL` | accepted、通道使能/credit/队列水位，限流或有界等待，不重放前缀 |
| `IO` / start失败 | 设备独占、权限、连接/ECAT模式、固件及AL错误，保留原错误，不自动保存配置/重启设备 |
| 回调无数据 | CAN接线/位率/应答、通道是否重新使能、是否注册回调，不先假定是DC问题 |

运行期同时看 `dmecat_get_stats`：`wkc_bad`、`worker_errors`、`channel_state[]`、各通道队列/credit、`rx_backpressure`、`rx_unhandled`。`FAULTED` 后先 stop 回收资源，再由应用决定是否重启；本版不提供自动断线恢复。

三个易误解口径：`submit` 成功只表示本地复制；`tx_submitted` 是 WKC 达标后的出队计数，不是 CAN TX-complete；`stop` 会取消本地待发且**不是 flush**，不保证从站在途帧已上线。端到端确认由业务按实际接收/应答和内容对账。每次成功 start 会重置本轮统计。

## 7. 让 AI 帮你接入

将 [AI 接入 Skill](skills/dmecat-sdk-consumer/SKILL.md) 和 SDK 解压路径提供给你使用的 AI 工具，让它先阅读 Skill，再根据本包公共头和示例接入应用。使用支持 Skill 的工具时，按该工具的规则添加整个 `skills/dmecat-sdk-consumer` 目录；也可直接让 AI 读取 `SKILL.md`。

示例需求：

> 阅读我提供的 dmecat-sdk-consumer/SKILL.md。SDK 位于我的本地解压目录，为现有 C++ 应用接入四通道发送与接收回调，先用 SM/1ms，只编译和做 --list 检查，不打开设备、不发 CAN。

Skill 不携带 DLL，也不会自动安装。请同时提供平台、应用语言、通道参数和测试范围；编译、枚举与实机收发应分别说明，避免 AI 在业务总线上误发帧。

## 8. 更多资料与许可

- [快速入门](docs/QUICK_START.md)：完整部署及操作顺序。
- [公共 ABI](docs/ABI_V1.md)：24 个导出、结构大小、线程与统计语义。
- [已知问题](docs/KNOWN_ISSUES.md)：缺帧/错载荷、WKC、平台与使用限制。
- [版本说明](docs/RELEASE_NOTES.md)：支持平台、版本功能、验证范围及未覆盖项。
- [许可与依赖说明](licenses/THIRD_PARTY_NOTICES.md)：随包组件、外部依赖及使用/再分发条款。

当前不提供任意 SDO、滤波表/恢复出厂/bus-off恢复公共接口、同步阻塞读、等待 CAN 完成的 flush、自动断线恢复或完整 C# 封装。应用应以公共头声明的接口为准，不应仅凭错误常量推断已有对应功能。

使用或再分发前请阅读 [许可与依赖说明](licenses/THIRD_PARTY_NOTICES.md)，并向供应方确认 SDK 及第三方组件的适用条款。SOEM 为 GPLv3 / 商业双许可，Npcap 不随包分发；下载文件或动态链接不代表获得额外授权。本预览版不承诺生产无损、长期 DC 锁定或长期稳定性。
