/** @file basic.c @brief 纯C应用：枚举网卡，显式选择后配置并收发CANFD。 */
#include <dmecat/dmecat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <time.h>
#endif

/** @brief 示例低频等待，业务收帧由SDK独立回调线程完成。 @param[in] ms 等待毫秒数。 */
static void wait_ms(unsigned ms)
{
#ifdef _WIN32
    Sleep(ms);
#else
    struct timespec delay = {ms / 1000u, (long)(ms % 1000u) * 1000000L};
    nanosleep(&delay, NULL);
#endif
}

/** @brief 独立交付线程上的接收回调，数据需要长期持有时由用户复制。 */
static void DMECAT_CALL on_frames(dmecat_device_t *device, const dmecat_frame_t *frames,
                                 uint32_t count, void *user_data)
{
    (void)device; (void)user_data;
    for (uint32_t i = 0; i < count; i++)
    { printf("RX ch=%u id=%X len=%u\n", frames[i].channel, frames[i].can_id, frames[i].dlen); }
}

/** @brief 输出当前线程的错误详情。 */
static void print_error(void)
{
    dmecat_error_t error = {0}; error.struct_size = sizeof(error);
    dmecat_get_last_error(&error);
    fprintf(stderr, "SDK error %d: %s\n", error.code, error.message);
}

int main(int argc, char **argv)
{
    if (argc < 2 || strcmp(argv[1], "--list") == 0)
    {
        uint32_t count = 0;
        if (dmecat_enum_adapters(NULL, 0, &count) != DMECAT_OK) { print_error(); return 1; }
        dmecat_adapter_t *items = (dmecat_adapter_t *)calloc(count ? count : 1, sizeof(*items));
        if (!items) { return 1; }
        if (dmecat_enum_adapters(items, count, &count) != DMECAT_OK)
        { free(items); print_error(); return 1; }
        for (uint32_t i = 0; i < count; i++) { printf("%s  %s\n", items[i].name, items[i].description); }
        free(items);
        printf("backend=%u\nUsage: example_c --list | <adapter> [--dc]\n", dmecat_get_backend());
        return 0;
    }
    dmecat_open_config_t config; dmecat_init_open_config(&config);
    dmecat_open_options_t options; dmecat_init_open_options(&options);
    if (argc > 3 || (argc == 3 && strcmp(argv[2], "--dc") != 0)) { return 1; }
    if (argc == 3) { options.sync_mode = DMECAT_SYNC_DC; }
    if (strlen(argv[1]) >= sizeof(config.adapter)) { return 1; }
    memcpy(config.adapter, argv[1], strlen(argv[1]) + 1u);
    dmecat_device_t *device = NULL;
    if (dmecat_open_ex(&config, &options, &device) != DMECAT_OK) { print_error(); return 1; }
    dmecat_baud_config_t baud; dmecat_init_baud_config(&baud);
    dmecat_status_t result = DMECAT_OK;
    for (uint32_t ch = 0; ch < 2 && result == DMECAT_OK; ch++)
    {
        result = dmecat_set_channel_baud(device, ch, &baud);
        if (result == DMECAT_OK) { result = dmecat_set_channel_enabled(device, ch, 1); }
    }
    // 当前兼容固件的CAN配置由低频任务生效；本等待不是发送完成或flush保证。
    wait_ms(1100u);
    if (result == DMECAT_OK) { result = dmecat_set_rx_callback(device, on_frames, NULL); }
    if (result == DMECAT_OK) { result = dmecat_start(device); }
    dmecat_frame_t frames[8] = {0};
    for (uint32_t i = 0; i < 8; i++)
    {
        frames[i].channel = 0; frames[i].can_id = 0x100 + i;
        frames[i].fdf = frames[i].brs = 1; frames[i].dlc = frames[i].dlen = 8;
        frames[i].payload[0] = (uint8_t)i;
    }
    uint32_t accepted = 0;
    if (result == DMECAT_OK) { result = dmecat_submit_batch(device, frames, 8, &accepted); }
    printf("accepted=%u\n", accepted);
    if (result != DMECAT_OK) { print_error(); }
    wait_ms(1000u);
    if (result == DMECAT_OK)
    {
        dmecat_sync_status_t sync = {0}; sync.struct_size = sizeof(sync);
        result = dmecat_get_sync_status(device, &sync);
        if (result == DMECAT_OK) { printf("sync=%u types=%u/%u active=%u\n",
            sync.sync_mode, sync.output_sync_type, sync.input_sync_type, sync.active); }
    }
    if (result != DMECAT_OK) { print_error(); }
    const dmecat_status_t closed = dmecat_close(&device);
    if (closed != DMECAT_OK) { print_error(); }
    if (result == DMECAT_OK) { result = closed; }
    return result == DMECAT_OK ? 0 : 1;
}
