using System;
using System.Runtime.InteropServices;

// 最小跨语言验证；callback委托和user_data必须由完整应用保持存活到stop返回。
internal static unsafe class Program
{
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    private struct OpenConfig
    {
        public uint StructSize;
        public uint AbiVersion;
        public fixed byte Adapter[512];
        public uint Slave;
        public uint PeriodUs;
        public uint FramesPerCh;
        public uint TxQueuePerCh;
        public uint RxQueueFrames;
        public uint RxTimeoutUs;
        public fixed uint Reserved[8];
    }

    /** @brief 0.3.0扩展参数，固定32B，不改变旧OpenConfig布局。 */
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    private struct OpenOptions
    {
        public uint StructSize;
        public uint Backend;
        public uint SyncMode;
        public int DcShiftNs;
        public fixed uint Reserved[4];
    }

    [DllImport("dmecat", CallingConvention = CallingConvention.Cdecl)]
    private static extern uint dmecat_get_abi_version();

    [DllImport("dmecat", CallingConvention = CallingConvention.Cdecl)]
    private static extern uint dmecat_get_sdk_version();

    [DllImport("dmecat", CallingConvention = CallingConvention.Cdecl)]
    private static extern void dmecat_init_open_config(out OpenConfig config);

    [DllImport("dmecat", CallingConvention = CallingConvention.Cdecl)]
    private static extern uint dmecat_get_backend();

    [DllImport("dmecat", CallingConvention = CallingConvention.Cdecl)]
    private static extern void dmecat_init_open_options(out OpenOptions options);

    private static int Main()
    {
        dmecat_init_open_config(out var config);
        dmecat_init_open_options(out var options);
        Console.WriteLine($"SDK={dmecat_get_sdk_version():X6} ABI={dmecat_get_abi_version()} backend={dmecat_get_backend()} config={sizeof(OpenConfig)} options={sizeof(OpenOptions)} period={config.PeriodUs}");
        return sizeof(OpenConfig) == 576 && config.StructSize == 576 && config.AbiVersion == 1 &&
            sizeof(OpenOptions) == 32 && options.StructSize == 32 && options.Backend == 0 && options.SyncMode == 0 &&
            config.PeriodUs == 1000 && dmecat_get_abi_version() == 1 ? 0 : 1;
    }
}
