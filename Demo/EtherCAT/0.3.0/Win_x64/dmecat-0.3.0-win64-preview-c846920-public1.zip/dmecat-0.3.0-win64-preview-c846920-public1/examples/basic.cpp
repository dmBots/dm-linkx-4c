/** @file basic.cpp @brief 公共C ABI完整接入：条件变量收帧、批次后缀重试及同句柄重启。 */
#include <dmecat/dmecat.h>
#include <array>
#include <chrono>
#include <condition_variable>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>
#include <vector>

namespace {
/** @brief 用户持有的回调上下文，至少存活到stop返回。 */
struct reception
{
    std::mutex mutex; /**< 回调与主线程的结果锁 */
    std::condition_variable cv; /**< 收帧完成通知 */
    std::array<bool, 8> seen{}; /**< 本示例8帧的唯一性 */
    unsigned count = 0; /**< 正确唯一条数 */
    bool invalid = false; /**< 重复或内容错误 */
};

/** @brief 只核对数据并唤醒主线程，不从回调调用生命周期操作。
 * @param[in] device 回调设备，不在本回调操作生命周期。
 * @param[in] frames 有效到回调返回的帧数组。 @param[in] count 帧数。
 * @param[in,out] context 用户持有的接收结果。
 */
void DMECAT_CALL receive(dmecat_device_t *device, const dmecat_frame_t *frames,
                         uint32_t count, void *context)
{
    (void)device;
    auto &rx = *static_cast<reception *>(context);
    std::lock_guard<std::mutex> lock(rx.mutex);
    for (uint32_t i = 0; i < count; ++i)
    {
        const auto &frame = frames[i];
        if (frame.can_id < 0x321u || frame.can_id >= 0x329u) { continue; }
        const auto n = frame.can_id - 0x321u;
        if (rx.seen[n] || frame.channel != 1u || frame.dlc != 8u || frame.dlen != 8u
            || !frame.fdf || !frame.brs || frame.ide || frame.rtr) { rx.invalid = true; }
        for (unsigned b = 0; b < 8u; ++b)
        { if (frame.payload[b] != n * 8u + b) { rx.invalid = true; } }
        if (!rx.seen[n]) { rx.seen[n] = true; ++rx.count; }
    }
    rx.cv.notify_all();
}

/** @brief 在失败的同一线程立即提取错误。
 * @param[in] status API返回值。 @param[in] action 操作名称。 @return 操作成功时为true。
 */
bool checked(dmecat_status_t status, const char *action)
{
    if (status == DMECAT_OK) { return true; }
    dmecat_error_t error{}; error.struct_size = sizeof(error);
    (void)dmecat_get_last_error(&error);
    std::fprintf(stderr, "%s: %d %s\n", action, status, error.message);
    return false;
}

/** @brief 低负载8帧闭环：等待实际接收，不将入队成功当作CAN上线确认。
 * @param[in] device 运行态设备。 @param[in,out] rx 接收核对结果。
 * @return 8帧内容及唯一性全部正确时为true。
 */
bool exchange(dmecat_device_t *device, reception &rx)
{
    std::array<dmecat_frame_t, 8> frames{};
    for (unsigned n = 0; n < frames.size(); ++n)
    {
        auto &frame = frames[n];
        frame.can_id = 0x321u + n; frame.channel = 0;
        frame.fdf = frame.brs = 1u; frame.dlc = frame.dlen = 8u;
        for (unsigned b = 0; b < 8u; ++b) { frame.payload[b] = (uint8_t)(n * 8u + b); }
    }
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    uint32_t offset = 0;
    while (offset < frames.size())
    {
        uint32_t accepted = 0;
        const auto status = dmecat_submit_batch(device, frames.data() + offset,
                                               (uint32_t)frames.size() - offset, &accepted);
        offset += accepted; // 只重试剩余后缀，不能重放已经接纳的前缀。
        if (status != DMECAT_OK && status != DMECAT_ERR_QUEUE_FULL) { return checked(status, "submit"); }
        if (std::chrono::steady_clock::now() >= deadline) { return false; }
        if (offset < frames.size())
        {
            std::unique_lock<std::mutex> lock(rx.mutex);
            rx.cv.wait_for(lock, std::chrono::milliseconds(1));
        }
    }
    std::unique_lock<std::mutex> lock(rx.mutex);
    rx.cv.wait_until(lock, deadline, [&] { return rx.count == frames.size() || rx.invalid; });
    std::printf("received=%u/8 valid=%s\n", rx.count, rx.invalid ? "no" : "yes");
    return rx.count == frames.size() && !rx.invalid;
}
}

/** @brief 枚举或执行两轮实际CAN闭环。
 * @param[in] argc 参数数。 @param[in] argv 网卡路径和可选--dc。
 * @return 0表示全部执行项通过，1表示参数或接入/核对失败。
 */
int main(int argc, char **argv)
{
    std::printf("SDK=%06X ABI=%u backend=%u\n", dmecat_get_sdk_version(),
                dmecat_get_abi_version(), dmecat_get_backend());
    if (argc == 1 || (argc == 2 && std::strcmp(argv[1], "--list") == 0))
    {
        uint32_t count = 0;
        if (!checked(dmecat_enum_adapters(nullptr, 0, &count), "enum")) { return 1; }
        std::vector<dmecat_adapter_t> adapters(count);
        if (!checked(dmecat_enum_adapters(adapters.data(), count, &count), "enum")) { return 1; }
        for (const auto &item : adapters) { std::printf("%s\n", item.name); }
        std::puts("Usage: example_cpp <adapter> [--dc]; requires CH0 connected to CH1");
        return 0;
    }
    if (argc > 3 || (argc == 3 && std::strcmp(argv[2], "--dc") != 0)) { return 1; }
    dmecat_open_config_t config; dmecat_init_open_config(&config);
    if (std::strlen(argv[1]) >= sizeof(config.adapter)) { return 1; }
    std::snprintf(config.adapter, sizeof(config.adapter), "%s", argv[1]);
    dmecat_open_options_t options; dmecat_init_open_options(&options);
    if (argc == 3) { options.sync_mode = DMECAT_SYNC_DC; }
    dmecat_device_t *device = nullptr;
    if (!checked(dmecat_open_ex(&config, &options, &device), "open")) { return 1; }
    reception rx;
    bool ok = true;
    dmecat_baud_config_t baud; dmecat_init_baud_config(&baud);
    for (uint32_t ch = 0; ch < 2u && ok; ++ch)
    {
        dmecat_baud_config_t actual{}; actual.struct_size = sizeof(actual);
        ok = checked(dmecat_set_channel_baud(device, ch, &baud), "baud")
            && checked(dmecat_get_channel_baud(device, ch, &actual), "read baud")
            && checked(dmecat_set_channel_enabled(device, ch, 1u), "enable");
    }
    // 当前固件配置由低频任务生效；该等待不是通用硬件完成屏障。
    std::this_thread::sleep_for(std::chrono::milliseconds(1100));
    ok = ok && checked(dmecat_set_rx_callback(device, receive, &rx), "callback");
    for (unsigned round = 0; round < 2u && ok; ++round)
    {
        { std::lock_guard<std::mutex> lock(rx.mutex); rx.seen.fill(false); rx.count = 0; rx.invalid = false; }
        ok = checked(dmecat_start(device), "start");
        if (ok)
        {
            dmecat_sync_status_t sync{}; sync.struct_size = sizeof(sync);
            ok = checked(dmecat_get_sync_status(device, &sync), "sync status");
            std::printf("round=%u sync=%u types=%u/%u active=%u\n", round + 1u,
                        sync.sync_mode, sync.output_sync_type, sync.input_sync_type, sync.active);
            ok = ok && exchange(device, rx);
        }
        const bool stopped = checked(dmecat_stop(device), "stop");
        ok = ok && stopped;
        { std::lock_guard<std::mutex> lock(rx.mutex); ok = ok && !rx.invalid && rx.count == 8u; }
    }
    const bool closed = checked(dmecat_close(&device), "close");
    return ok && closed ? 0 : 1;
}
