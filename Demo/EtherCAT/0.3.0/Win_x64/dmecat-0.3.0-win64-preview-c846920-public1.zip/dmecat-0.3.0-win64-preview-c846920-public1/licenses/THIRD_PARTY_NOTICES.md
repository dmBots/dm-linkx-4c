# SDK 与第三方组件说明

使用或再分发本 SDK 前，请阅读适用条款及组件许可原文。本说明不替代许可证，也不授予额外权利。

## LinkX4C EtherCAT SDK

本包包含 SDK 动态库、公共头、示例及文档。SDK 本体的使用和再分发条款请向供应方确认；仓库可访问或文件可下载，不代表 SDK 已按开源许可证授权。

## Windows：SOEM 2.0.0

Windows 包包含独立动态库 `bin/x64/soem.dll`，仅支持 **SOEM 2.0.0**。原始许可说明为 **GPLv3 / 商业双许可**，不是 LGPL；动态链接不代表获得额外授权。

请阅读 Windows 包内的 `licenses/SOEM-LICENSE.md`；具体版本和来源记录在 `licenses/soem-version.txt`。本包未附 SOEM 商业许可证明，适用的授权和再分发条件请向供应方确认。

官方资料：[SOEM v2.0.0](https://github.com/OpenEtherCATsociety/SOEM/tree/v2.0.0)、[许可原文](https://github.com/OpenEtherCATsociety/SOEM/blob/v2.0.0/LICENSE.md)。Linux 包不包含 SOEM。

## Linux：IgH

Linux SDK 动态依赖 IgH 用户态库，按 **1.5.4 / API 1.5** 接入。IgH 用户态库、内核模块和工具不随本包提供，需要另行安装；适用许可以所安装组件的随附材料为准。

官方项目：[IgH EtherCAT Master](https://etherlab.org/en/ethercat/)。

## Npcap 与 Microsoft 运行时

Windows 需要另行安装 Npcap 的 WinPcap API 兼容支持和 MSVC x64 Release 运行时。Npcap 驱动、安装程序、SDK 及 Microsoft 运行时安装程序均不在本包内；请从官方渠道获取，并确认安装权限和适用条款。

官方入口：[Npcap](https://npcap.com/)、[Microsoft Visual C++ 运行时](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist)。
