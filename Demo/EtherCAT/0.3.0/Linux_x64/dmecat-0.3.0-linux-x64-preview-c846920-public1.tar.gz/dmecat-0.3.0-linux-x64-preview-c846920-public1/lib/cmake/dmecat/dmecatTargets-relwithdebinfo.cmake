#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dmecat::dmecat" for configuration "RelWithDebInfo"
set_property(TARGET dmecat::dmecat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(dmecat::dmecat PROPERTIES
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/libdmecat.so.0.3.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libdmecat.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS dmecat::dmecat )
list(APPEND _IMPORT_CHECK_FILES_FOR_dmecat::dmecat "${_IMPORT_PREFIX}/lib/libdmecat.so.0.3.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
